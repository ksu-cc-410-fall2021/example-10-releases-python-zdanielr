"""Test Package for guessing game.

Author: Zach Rankin zdanielr@ksu.edu
Version: 0.1
"""
